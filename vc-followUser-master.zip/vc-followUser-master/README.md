# FollowUser

Adds a follow option in the user context menu to always be in the same VC as them

![Screenshot](./screenshot.png)

# Installation
See the [forum thread](https://discord.com/channels/1015060230222131221/1257038407503446176/1257038407503446176) / [Vencord docs](https://docs.vencord.dev/installing/custom-plugins/)
